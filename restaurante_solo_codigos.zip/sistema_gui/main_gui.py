import tkinter as tk
from tkinter import ttk, messagebox
from modelo.item import MainCourse, Beverage, Dessert
from modelo.pedido import Order

menu = {
    "Hamburguesa": {"price": 12.0, "type": "MainCourse"},
    "Pizza": {"price": 15.0, "type": "MainCourse"},
    "Refresco": {"price": 3.0, "type": "Beverage"},
    "Agua": {"price": 2.0, "type": "Beverage"},
    "Helado": {"price": 5.0, "type": "Dessert"},
    "Pastel": {"price": 6.0, "type": "Dessert"}
}

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Pedidos - Restaurante")

        self.order = Order()

        tk.Label(root, text="Menú del Restaurante", font=("Arial", 14)).pack(pady=5)

        self.producto = ttk.Combobox(root, width=40, state="readonly")
        self.producto['values'] = [f"{k} - ${v['price']} ({v['type']})" for k, v in menu.items()]
        self.producto.pack(pady=5)

        tk.Button(root, text="Agregar al pedido", command=self.agregar_producto).pack(pady=5)

        self.lista = tk.Listbox(root, width=50, height=8)
        self.lista.pack(pady=5)

        tk.Button(root, text="Calcular total y pagar", command=self.procesar_pago).pack(pady=5)

        self.total_label = tk.Label(root, text="Total: $0.00", font=("Arial", 12, "bold"))
        self.total_label.pack(pady=5)

    def agregar_producto(self):
        seleccionado = self.producto.get()
        if not seleccionado:
            return
        nombre = seleccionado.split(" - ")[0]
        datos = menu[nombre]
        tipo = datos["type"]
        precio = datos["price"]

        if tipo == "MainCourse":
            item = MainCourse(nombre, precio)
        elif tipo == "Beverage":
            item = Beverage(nombre, precio)
        else:
            item = Dessert(nombre, precio)

        self.order.add_item(item)
        self.lista.insert(tk.END, f"{nombre} - ${precio:.2f}")

    def procesar_pago(self):
        total = self.order.calculate_total()
        self.total_label.config(text=f"Total: ${total:.2f}")
        messagebox.showinfo("Pago", f"Pago procesado. Total: ${total:.2f}")
        self.order = Order()
        self.lista.delete(0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()

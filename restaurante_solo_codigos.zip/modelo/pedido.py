class Order:
    def __init__(self):
        self.items = []

    def add_item(self, item):
        self.items.append(item)

    def calculate_total(self):
        total = 0
        has_main = any(isinstance(i, MainCourse) for i in self.items)
        for item in self.items:
            if isinstance(item, Beverage) and has_main:
                total += item.get_price() * 0.9
            else:
                total += item.get_price()
        return total

class Payment:
    def __init__(self, order, payment_method):
        self.order = order
        self.payment_method = payment_method

    def process_payment(self):
        total_price = self.order.calculate_total()
        print(f"Pago de ${total_price:.2f} realizado con {self.payment_method}. ¡Gracias!")

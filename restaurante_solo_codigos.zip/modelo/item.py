class MenuItem:
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def get_price(self):
        return self.price

class MainCourse(MenuItem): pass
class Beverage(MenuItem): pass
class Dessert(MenuItem): pass
